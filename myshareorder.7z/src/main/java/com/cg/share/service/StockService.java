package com.cg.share.service;

import java.util.List;

import com.cg.share.dto.Stock;
import com.cg.share.exception.StockException;

public interface StockService {

    List<Stock> getAllStock()  throws StockException;
	List<Stock> addStock(Stock stock) throws StockException;
	Stock getStockById(int id)  throws StockException;
	List<Stock> deleteProductById(int id)throws StockException;
	List<Stock> updateStock(Stock stock, int id) throws StockException;
	

}
