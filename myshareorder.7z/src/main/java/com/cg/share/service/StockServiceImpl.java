package com.cg.share.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.share.dao.StockRepository;
import com.cg.share.dto.Stock;
import com.cg.share.exception.StockException;
@Service
public class StockServiceImpl implements StockService{
  @Autowired
	public StockRepository stockdao;
	
	@Override
	public List<Stock> getAllStock() throws StockException {
		
		try {
			return stockdao.findAll();
		} catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}

		
		

	@Override
	public Stock getStockById(int id) throws StockException {
		try {
			Optional<Stock> data= stockdao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}
			else {
				throw new StockException("product with Id "+id+"does not match");
			}
		} catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}

	@Override
	public List<Stock> deleteProductById(int id) throws StockException {

		if(stockdao.existsById(id)) {
			stockdao.deleteById(id);
			return getAllStock();
		}else {
			throw new StockException("product with Id "+id+"does not match");	
		}	
		
	}




	@Override
	public List<Stock> addStock(Stock stock) throws StockException {
		double brokencharges;
		double price=stock.getPrice();
		int quantity=stock.getQuantity();
		double amount=price*quantity;
		if(quantity<100) {
		  brokencharges=((0.5)*amount)/100;
		}else {
			brokencharges=((0.3)*amount)/100;
		}
		stock.setAmount(amount);
		stock.setBrokerage(brokencharges);
		stockdao.save(stock);
		return getAllStock();			
				
	}




	@Override
	public List<Stock> updateStock(Stock stock, int id) throws StockException {
		if(stockdao.existsById(id)) {
			stock.setId(id);
			double brokencharges;
			double price=stock.getPrice();
			int quantity=stock.getQuantity();
			double amount=price*quantity;
			if(quantity<100) {
			  brokencharges=((0.5)*amount)/100;
			}else {
				brokencharges=((0.3)*amount)/100;
			}
			stock.setAmount(amount);
			stock.setBrokerage(brokencharges);
			stockdao.save(stock);
			return getAllStock();
		}else {
			  throw new StockException("Invalid stock id,cannot be updated");
		}
	}


}
