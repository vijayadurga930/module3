package com.cg.share.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cg.share.dto.Stock;
import com.cg.share.exception.StockException;
import com.cg.share.service.StockService;

@RequestMapping("/api")
@RestController
public class StockController {
	@Autowired
	
	public StockService service;
	
	@GetMapping("/shares")
	public List<Stock> getAllStocks() throws StockException{
		return service.getAllStock();
		
	}
	
	@PostMapping("/shares")
	public List<Stock> addStock(@RequestBody Stock stock ) throws StockException{
		return service.addStock(stock);
		
	}
	

	@GetMapping("/shares/{id}")
	public Stock getStockById(@PathVariable int id) throws StockException{
		return service.getStockById(id);
	
	}
	@DeleteMapping("/shares/{id}")
	public List<Stock> deleteStock(@PathVariable int id) throws StockException{
	
     return service.deleteProductById(id);
	}
	@PutMapping("/shares/{id}")
	public List<Stock> updateStock(@RequestBody Stock stock,@PathVariable int id )
			throws StockException{
		return service.updateStock(stock,id);
}
}