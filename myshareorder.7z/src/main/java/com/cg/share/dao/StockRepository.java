package com.cg.share.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.share.dto.Stock;


public interface StockRepository  extends JpaRepository<Stock,Integer>{
	/*
	 * @Query("from Product where category=:category") List<Stock>
	 * getProductByCategory(@Param("category") String category);
	 */

}
