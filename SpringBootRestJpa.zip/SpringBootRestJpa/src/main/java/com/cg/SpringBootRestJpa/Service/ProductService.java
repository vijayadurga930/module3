package com.cg.SpringBootRestJpa.Service;

    
import java.util.List;


import com.cg.SpringBootRestJpa.Beans.Product;
import com.cg.SpringBootRestJpa.Exception.ProductException;


public interface ProductService {


    public List<Product> addProduct(Product pro) throws ProductException;
    public Product getProductById(long id) throws ProductException;
    public void deleteProduct(long id) throws ProductException;
    public List<Product> getAllProducts() throws ProductException;
    public List<Product> updateProduct(long id,Product pro) throws ProductException;
    List<Product> getByQuantity(int quantity) throws ProductException;
    List<Product> getByPrice(int price) throws ProductException;
    
}
 





