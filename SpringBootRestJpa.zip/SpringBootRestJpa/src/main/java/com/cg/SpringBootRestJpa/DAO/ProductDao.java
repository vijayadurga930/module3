package com.cg.SpringBootRestJpa.DAO;

import java.util.List;
import java.util.Optional;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

 

import com.cg.SpringBootRestJpa.Beans.Product;
@Repository
public interface ProductDao extends JpaRepository<Product,Long>{
    @Query("from Product where id=:c")
    Optional<Product> findById(@Param("c") long id);
    
    @Query("from Product where quantity>:q")
    List<Product> getByQuantity(@Param("q") int quantity);
    
    @Query("from Product product where product.price > :price")
    List <Product> getByPrice(@Param("price")int price);
   /* @Query("from Product where id=:c")
    void deleteById(@Param("c") long id);
*/
 

}