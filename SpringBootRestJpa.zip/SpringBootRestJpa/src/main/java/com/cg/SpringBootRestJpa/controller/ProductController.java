package com.cg.SpringBootRestJpa.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.SpringBootRestJpa.Beans.Product;
import com.cg.SpringBootRestJpa.Exception.ProductException;
import com.cg.SpringBootRestJpa.Service.ProductService;
import com.cg.SpringBootRestJpa.Service.ProductServiceImpl;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping("/products")
	public List <Product> getAllProductss() throws ProductException
	{
		return productService.getAllProducts();
	}
	
	@RequestMapping(value="/product", method=RequestMethod.POST)
	public List<Product> addProduct(@RequestBody Product pro) throws ProductException
	{
		return productService.addProduct(pro);
			}
	
	@RequestMapping(value="/product/{id}")
	public Product getProductById(@PathVariable long id) throws ProductException {
		
		return productService.getProductById(id);
	}
	
	@DeleteMapping("/product/{id}")
	public ResponseEntity<String> deleteBook(@PathVariable long id) throws ProductException
	{
		productService.deleteProduct(id);
		return new ResponseEntity<String> ("Product with id" +id+"deleted",HttpStatus.OK);
	}
	
	@PutMapping("/products/{id}")
	public List <Product> updateProduct(@PathVariable long id, @RequestBody Product pro) throws ProductException
	{
		return productService.updateProduct(id, pro);
	}
	
	@RequestMapping("/getByQuantity/{quantity}")
	public List<Product> getByQuantity(@PathVariable int quantity) throws ProductException{
		return productService.getByQuantity(quantity);
	}
	
	@RequestMapping("/getByPrice/{price}")
	public List<Product> getByPrice(@PathVariable int price)throws ProductException{
		
		return productService.getByPrice(price);
				}
	

	
}
