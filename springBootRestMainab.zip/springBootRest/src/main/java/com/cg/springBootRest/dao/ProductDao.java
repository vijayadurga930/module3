package com.cg.springBootRest.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.springBootRest.bean.Product;


public interface ProductDao extends JpaRepository<Product, Long>{



	@Query("from Product where id = :c")
	Optional<Product> findById(@Param("c") long id);

	@Query("from Product where price > :p")
	List<Product> findByPrice(@Param("p") int price);

	@Query("from Product where quantity > 2")
	List<Product> findByQty();

//	@Query("from Product where id = :c")
//	void deleteById(@Param("c") Long id);


	@Query("from Product product where product.price between:price and :price1")
	    List<Product> findByPrice(@Param("price") int price, @Param("price1")int price1);


	
}
