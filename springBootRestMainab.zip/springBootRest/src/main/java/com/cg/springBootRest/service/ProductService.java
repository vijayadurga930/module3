package com.cg.springBootRest.service;
import java.util.List;

import com.cg.springBootRest.bean.Product;
import com.cg.springBootRest.exception.ProductException;


public interface ProductService {

	public List<Product> addProduct(Product pro) throws ProductException;
	public Product getProductById(long id) throws ProductException;
	public void deleteProduct(long id) throws ProductException;
	public List<Product> getAllProducts() throws ProductException;
	public List<Product> updateProduct(long id,Product pro) throws ProductException;
	public List<Product> getProductByPrice(int price) throws ProductException;
	public List<Product> getAllProductsByQty() throws ProductException;
	List<Product> findByPrice(int price, int price1) throws ProductException;
	
}

